# Deliverable 05: 30 LinkedIn Posts

## Purpose

30 LinkedIn posts ready to publish. Each post is fully written, not an idea or a topic. The mix is engineered for variety: hook formats, post lengths, content types, and emotional registers all rotate so the founder's feed never looks repetitive.

## Format mix (the 30-post matrix)

Distribute the 30 posts across these 6 formats. Use exact counts so the mix is intentional, not random.

| Format | Count | What it looks like | When it wins |
|--------|-------|--------------------|--------------|
| Long-form story post | 6 | 200-400 words, narrative arc with a takeaway | Trust, depth, reposts |
| Contrarian take | 5 | 80-150 words, sharp POV with one piece of evidence | Reach, comment volume |
| Tactical how-to | 5 | 150-250 words, numbered or stepped | Saves, DMs |
| List post | 4 | 120-200 words, "X things I learned" format | Easy consumption, broad reach |
| Question / poll-style | 4 | 30-80 words, opens a conversation | Comments, audience research |
| Client win / case study | 3 | 150-250 words, before-state to after-state | Conversions, social proof |
| Short observation | 3 | 30-80 words, one-liner with reasoning | Algorithmic spike, low-effort wins |

Total: 30. If you drift, audit at the end and rebalance.

## Hook variety rules

Every post starts with a hook. Across the 30 posts, hooks must rotate. No more than 5 posts use the same hook pattern.

Hook patterns to rotate through:
- **Contrarian:** "Most {audience} think X. They're wrong, and here's why..."
- **Story scene:** "Tuesday morning. The {audience} sat across from me and said..."
- **Specific number:** "I've watched {N} {audience} do this. {N-X} get it wrong."
- **Question:** "Why do {audience} keep doing X when they know it doesn't work?"
- **Confession:** "For years I told my clients to do X. I was wrong."
- **Pattern interrupt:** "Stop {common action}. Start {counter action}. Here's why..."
- **News peg:** "I just saw {industry event/story}. Here's what most people missed."
- **Direct claim:** "{Audience} who do X make {specific outcome}. Everyone else doesn't."

## Output structure

```markdown
# 30 LinkedIn Posts — {Founder First Name}

## Brand Context
{full brand context block}

## 30 LinkedIn Posts

### Format mix
- Long-form stories: 6
- Contrarian takes: 5
- Tactical how-tos: 5
- List posts: 4
- Question / conversation posts: 4
- Client wins: 3
- Short observations: 3

### Posting guidance
{4-5 lines: best posting time for her audience, ideal cadence, how to space contrarian takes from client wins, when to use a poll vs a question post}

### The 30 posts

#### LinkedIn Post 01 — {Format type}

**Hook pattern:** {pattern name from the list above}
**Content pillar:** {which of the 5-10 pillars this post draws from}

{Full post body, formatted exactly as it would appear on LinkedIn. Line breaks every 1-2 sentences. Hook on its own line at the top. Close with either a question, a takeaway line, or a CTA.}

**Suggested CTA:** {if applicable: "comment X below," "DM me Y," or "the lead magnet is in the comments"}

---

[Repeat for posts 02 through 30]
```

## Per-post quality rules

- Every post is **publishable as-is**. No "fill in" placeholders except for genuinely client-specific data (`[INSERT: specific revenue number]`, `[INSERT: client first name]`). Aim for fewer than 3 placeholder posts out of 30.
- Every post ends with **either a question, a takeaway, or a CTA**. Never a hashtag dump. Never a "thoughts?" alone.
- Long-form story posts have a **clear narrative arc**: setup, tension, resolution, takeaway.
- Contrarian takes name the **specific belief being challenged**. Vague "common wisdom is wrong" posts are weak. "Most coaches tell you to {specific thing}. That's why their clients {specific bad outcome}" is strong.
- Tactical posts are **executable today**. The reader should know what to do by Friday.
- Client wins use the **before-state → trigger → action → result → lesson** structure.

## Distribution across content pillars

Spread the 30 posts across the founder's 5-10 content pillars. No pillar gets more than 8 posts. No pillar gets fewer than 1 post. If a pillar has only 1 post, audit whether it deserves to be a pillar.

## Tone rules

- Founder voice from the brand context block.
- No corporate filler ("delighted to share," "humbled to announce," "thrilled").
- No em dashes.
- No emoji unless the brand context explicitly allows them.
- First-person singular ("I") not first-person plural ("we") unless she runs a team and the post is about the team.
- LinkedIn-native formatting: line breaks every 1-2 sentences, no walls of text, no markdown bold (LinkedIn doesn't render it).

## Tailoring quality bar

- At least 5 posts directly echo the founder's contrarian POV from the brand context
- At least 8 posts use a specific audience pain (in their words) in the body
- At least 3 posts reference a specific industry, geography, or sub-niche detail that only this founder would write
- Zero posts could be republished verbatim by another founder in the same broad space

If you cannot pass that last test, the posts are too generic. Rewrite.

## Length

Total deliverable file should be 4500-6500 words for all 30 posts combined.
