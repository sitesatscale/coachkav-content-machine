# Deliverable 06: 30 X / Twitter Posts

## Purpose

30 X (Twitter) posts ready to publish. X is a different medium from LinkedIn: shorter, punchier, more idea-density per character, more comfortable with strong opinions. The 30 posts should sound noticeably different from the LinkedIn pack even when drawn from the same content pillars.

## Format mix

| Format | Count | What it looks like | Char range |
|--------|-------|--------------------|------------|
| One-liner | 12 | Single tweet, sharp claim or observation | 80-220 |
| Two-tweet | 6 | Tweet + reply that adds the unlock | 80-200 each |
| Mini-thread (4-6 tweets) | 6 | Tight thread, one idea per tweet | 100-220 each tweet |
| Long thread (8-12 tweets) | 3 | Deep dive, narrative or framework | 120-250 each tweet |
| Question post | 2 | Genuine question that invites replies | 60-180 |
| Quote / observation post | 1 | Single line that could be a tweet of the year | <140 |

Total: 30 standalone units (a thread counts as one unit, even though it has multiple tweets).

## Output structure

```markdown
# 30 X / Twitter Posts — {Founder First Name}

## Brand Context
{full brand context block}

## 30 X / Twitter Posts

### Format mix
- One-liners: 12
- Two-tweet posts: 6
- Mini-threads (4-6 tweets): 6
- Long threads (8-12 tweets): 3
- Question posts: 2
- Quote / observation post: 1

### Posting guidance
{3-4 lines: best posting time for the founder's audience, how X behaves differently from LinkedIn, when to reply vs quote-tweet for distribution}

### The 30 posts

#### Post 01 — {Format type}

**Hook pattern:** {pattern label}
**Content pillar:** {which pillar}

{Full post body. For threads, number each tweet 1/N, 2/N, etc. and put each tweet on its own paragraph.}

---

[Repeat for posts 02 through 30]
```

## Format-specific guidance

### One-liners (12 total)
- A complete thought in one tweet. No setup-payoff that requires a reply.
- The strongest one-liners are claims that someone could disagree with.
- Aim for 80-180 characters. Tweets shorter than 60 characters look thin. Tweets pushing 280 should be a two-tweet.
- Example pattern: "The difference between {audience who wins} and {audience who doesn't} is {one specific thing}."

### Two-tweet posts (6 total)
- Tweet 1: hook or claim. Tweet 2 (as a reply to your own tweet): the unlock, mechanism, or example.
- The "reply to self" pattern outperforms cramming both into one tweet.
- Tweet 2 should not be required to understand tweet 1. Tweet 1 must stand alone.

### Mini-threads (6 total, 4-6 tweets each)
- Tweet 1: hook + promise of the unlock
- Tweets 2-5: the actual content, one idea per tweet
- Last tweet: takeaway or CTA (lead magnet, follow CTA, or "what would you add")
- Each tweet readable on its own. No "context above" dependencies.

### Long threads (3 total, 8-12 tweets each)
- Reserved for narrative posts or framework breakdowns
- Tweet 1: the hook needs to earn 8+ tweets of attention. Numbers, stakes, or a story scene.
- One idea per tweet. Resist the urge to cram.
- Closing tweet: explicit CTA. Long threads are the format that converts.

### Question posts (2 total)
- A genuine question, not a fake one. "What's something you stopped doing this year?" not "Agree?"
- The question should be one the founder genuinely wants to know the answer to. The replies become content fuel.

### Quote / observation post (1 total)
- The single best line in the pack. Stand-alone wisdom that someone would screenshot.
- Aim for under 140 characters so it has visual weight.
- This is the post the founder pins to her profile if it lands.

## Voice on X vs LinkedIn

X tolerates and rewards:
- Sharper opinions
- Light irreverence (if it fits her voice cues)
- Inside-baseball industry references
- Stripped-down formatting (no line-break-every-sentence theater)
- Lowercase openers (if it fits her voice)

X does not tolerate:
- LinkedIn-style "humbled to share" openings
- Corporate hedging
- Long setups before the point
- Em dashes
- Hashtag dumps

## Tailoring quality bar

- At least 6 of the 30 echo the founder's contrarian POV in some form
- At least 4 reference a specific pain in the audience's own words
- At least 1 long thread is built around her origin moment or a specific client win
- Zero posts could be a generic motivational tweet

## Length

Total deliverable file should be 3500-5000 words across the 30 posts (threads inflate the word count).
