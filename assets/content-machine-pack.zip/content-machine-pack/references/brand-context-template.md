# Brand Context Block Template

This block sits at the top of every deliverable file in the pack. It is the single source of truth that grounds the voice, niche, audience, and offer across all nine assets. If the user updates the context block in one file, they should update it everywhere — or treat `00-brand-context.md` as the canonical version.

## Schema

Use this exact structure and these exact headers. Fill every field. Use `[TO CONFIRM]` for anything genuinely unknowable from the intake.

```markdown
## Brand Context

**Founder:** {full name}, {role or credential line}
**Business:** {business name}, {one-line description}
**Category and niche:** {category} / {specific niche}
**Stats:** {revenue or clients served} / {years in business} / {awards or credentials}
**Geography:** {local, regional, national, or global}

**Ideal customer:**
{2-3 sentences in plain language describing exactly who this is, including life stage, role, situation, and what triggers them to look for a solution}

**Audience pains (in their words):**
- {pain 1, in the audience's language}
- {pain 2}
- {pain 3}
- {pain 4 if applicable}
- {pain 5 if applicable}

**Desired outcomes (in their words):**
- {outcome 1}
- {outcome 2}
- {outcome 3}
- {outcome 4 if applicable}
- {outcome 5 if applicable}

**Primary offer:** {offer name}, {format}, {price band}
**Offer ladder:** {free → low-ticket → mid → high, with names and prices}
**Buyer journey:** {short arrow-separated path from first touch to purchase}

**Voice cues:**
- Sounds: {three adjectives, comma-separated}
- Never sounds: {two anti-patterns, comma-separated}
- Signature moves: {1-2 specific verbal habits, optional}

**Founder POV / contrarian belief:**
{1-2 sentences capturing the strongest opinion she will repeat across the pack. This drives at least 5 of the 30 LinkedIn posts and at least 3 of the 30 Twitter posts.}

**Origin or authority moment:**
{1-2 sentences on the lived experience or scar that earns her the right to say the contrarian belief}

**Content pillars:**
1. {pillar 1}
2. {pillar 2}
3. {pillar 3}
4. {pillar 4}
5. {pillar 5}
6. {add up to 10 if relevant}

**Primary platform:** {platform name}
**Primary CTA:** {specific CTA the pack drives toward}
**Off-limits:** {topics, words, or framings to avoid}
```

## How to populate it

**From a Brand DNA doc:** Pull verbatim where possible. The Audience Deep Dive section feeds pains and outcomes. The Founder-Market Fit section feeds origin. The Brand Positioning section feeds POV. The Monetization section feeds offer ladder. The Content Strategy section feeds pillars.

**From an intake form:** Map question by question using the intake-template.md numbering. Question 7 → pains. Question 8 → outcomes. Question 15 → POV. Question 17 → pillars.

**From conversation context:** If the user has discussed the founder over multiple messages, synthesize. Pull direct quotes where the user wrote in the founder's voice or quoted the audience.

## Quality bar

The brand context block should be specific enough that:
- The pains read like the customer wrote them, not the marketing team
- The POV is sharp enough that some readers will disagree with it
- The offer ladder is concrete (named offers and prices, not "various services")
- The voice cues are usable — "direct, warm, slightly contrarian" works; "professional, friendly, engaging" does not

If three or more fields are vague or boilerplate, the block is not done. Push the user one more round before generating the pack.

## Where it appears

Every deliverable file in the pack starts with this block under a `## Brand Context` header, immediately after the file title. This makes each file a portable, self-grounding artifact the client can hand to a writer or VA without losing the strategic spine.
