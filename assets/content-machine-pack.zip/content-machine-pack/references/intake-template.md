# Content Machine Intake

Use this question set when no Brand DNA document, brand strategy doc, or substantial intake form is provided. Ask all questions in a single message, numbered, so the user can answer in one pass.

## Opening line

```
Before I build the pack, I need to ground every deliverable in the founder's actual reality. Please answer the questions below in one reply. Skip any that don't apply and I'll work from what you give me.
```

## The questions

**Founder and business**
1. Founder's full name and title
2. Business name and one-line description of what the business does
3. Industry, niche, and sub-niche (be specific: not "fitness" but "strength training for women over 40")
4. Years in business, revenue band, number of clients served, and any awards or notable credentials worth featuring
5. Geographic focus (local, regional, national, global)

**Audience**
6. Who is the ideal customer in plain language? (role, life stage, situation, income band if relevant)
7. What are the three to five biggest pains, frustrations, or fears this customer is actively dealing with? Use their own words where possible.
8. What are the three to five outcomes or transformations they most want?
9. Where does this customer currently spend time online? (platforms, communities, newsletters they read, people they follow)

**Offer**
10. What is the primary offer the content pack should ladder toward? Include price band and delivery format.
11. What other offers exist in the stack, in order from low to high ticket?
12. What is the typical buyer journey from first touch to purchase? (e.g., free content → lead magnet → call → sale)

**Voice and POV**
13. Three adjectives that describe the founder's voice (e.g., direct, warm, slightly contrarian)
14. Two things the voice should never sound like (e.g., never preachy, never corporate-jargony)
15. The founder's contrarian belief or strongest opinion about the industry. What does she think most peers get wrong?
16. The origin moment, scar, or lived experience that earns her authority to speak on this topic

**Content territory**
17. Five to ten content pillars or topic territories the founder owns or wants to own
18. Two or three competitors or adjacent voices in the space (so the pack avoids sounding like them)
19. Any topics, words, or framings that are explicitly off-limits

**Distribution**
20. Which platforms is the founder actively publishing to right now, and which is the primary platform for this pack?
21. Posting cadence on the primary platform (current and target)
22. Any existing lead magnet, email list size, or social following stats worth knowing

**Pack specifics**
23. Primary CTA the pack should drive to (book a call, download the lead magnet, join the waitlist, buy the product)
24. Hard "do" or "don't" the founder has stated about her content (e.g., "no personal stories about my kids," "always include a question at the end")
25. Anything else that would change how I write this pack

## After the user answers

Confirm before generating:
- If any answer is missing or unclear, ask one targeted follow-up rather than re-asking the full question
- If question 15 (contrarian belief) is generic or weak, push once: "Give me a sharper version. What is the one thing she says out loud that makes her audience nod and her peers uncomfortable?"
- If question 7 (audience pains) uses marketing language rather than customer language, push once: "Give me how the customer actually talks about this in private, not how the marketing brochure says it."

Then proceed to Step 2 of the main workflow (build the brand context block).
