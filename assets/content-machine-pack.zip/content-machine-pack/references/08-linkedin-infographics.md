# Deliverable 08: 5 LinkedIn Infographic Concepts

## Purpose

5 LinkedIn infographic concepts. These are different from Instagram carousels in two ways: they are typically single-image (or a 2-3 image LinkedIn document upload), and they are denser. LinkedIn rewards proof, density, and "save for later" value over emotional pull.

## The 5 concept types

| # | Concept type | Strategic function |
|---|--------------|-------------------|
| 1 | The Framework Map | A visual diagram of the founder's model or system |
| 2 | The Comparison Grid | Old way vs. new way, or competitor approach vs. founder's approach |
| 3 | The Decision Tree | "If X then do Y" branching visual that solves an audience decision |
| 4 | The Stat Stack | Data-driven proof points organized visually |
| 5 | The Process Map | Step-by-step visual workflow or transformation timeline |

## Output structure

```markdown
# 5 LinkedIn Infographic Concepts — {Founder First Name}

## Brand Context
{full brand context block}

## 5 LinkedIn Infographic Concepts

### Visual style direction
{4-6 lines covering: brand palette (limit to 3-4 colors), typography preference, whether to use icons or photos, density tolerance, whether the founder's photo appears, watermark or logo placement}

### The 5 concepts

#### Infographic 01: {Concept type} — "{Working title}"

**Strategic function:** {one line}
**Pillar:** {which pillar}
**Format:** {single image, 2-image carousel, 3-image carousel, or LinkedIn PDF document}
**Estimated design time:** {30-120 min}

**Layout description:**
{2-3 paragraphs describing the visual layout from top to bottom. Specific enough that a designer could mock it up without follow-up questions. Mention: header element, main visual element, supporting elements, footer/CTA placement, and the visual hierarchy.}

**All text on the infographic (exact copy):**

**Header:** "{exact text}"
**Sub-header (if applicable):** "{exact text}"

**Body labels (in order of reading):**
1. {exact text}
2. {exact text}
3. {exact text}
...

**Footnote / source line:** "{if any}"
**Footer CTA or attribution:** "{e.g., "Save this. Built by {Founder} at {Business}." or "More at {handle}."}"

**Accompanying LinkedIn post copy:**
{Full post body that accompanies the infographic when published. 100-200 words. Opens with a hook. References the infographic. Closes with a CTA (save, share, comment, or DM).}

---

[Repeat for infographics 02 through 05]
```

## Per-concept content rules

**Infographic 1 (Framework Map):**
- Visualize the founder's framework as a diagram. Common patterns: pyramid, flywheel, matrix, ladder, arrow flow.
- Pick the pattern that matches the framework's actual structure. Don't force a pyramid onto a process that's linear.
- Label every component. No floating boxes without text.

**Infographic 2 (Comparison Grid):**
- Two columns. Old way / New way (or competitor / founder).
- 5-7 rows of comparison points.
- Each row: a specific claim, not "better" vs "worse." E.g., "Generic playbook" vs "Built from her customer's actual transcripts."
- Header row labels both columns clearly.

**Infographic 3 (Decision Tree):**
- Start with a question the audience genuinely asks
- Branch into 2-3 paths based on their answer
- Each path ends in a specific recommendation
- Keep branches under 3 levels deep. Deeper trees become unreadable.

**Infographic 4 (Stat Stack):**
- 4-6 data points presented visually (big numbers + short context line each)
- Stats can come from the founder's own client data, industry research, or her case study results
- If the founder doesn't have stats, propose what would need to be gathered and mark `[INSERT: specific stat]`
- Footnote: source line for credibility

**Infographic 5 (Process Map):**
- A visual workflow: client journey, transformation timeline, or step-by-step method
- 5-8 stages, left to right or top to bottom
- Each stage: stage name, 1-line description, optional sub-bullet
- End stage should be the outcome the audience wants

## Tone

Infographic copy is dense and declarative. No filler. Every word visible on the image earns its space. The accompanying LinkedIn post can have more breathing room.

## Tailoring quality bar

- At least 2 of the 5 use the founder's own framework, stats, or process. If she doesn't have one, the deliverable proposes one drawn from her POV.
- The comparison grid (infographic 2) is built around the founder's contrarian POV from the brand context
- Every infographic's accompanying post drives to the primary CTA or a derivative of it (newsletter signup, DM, save)
- No infographic could be republished by a generic agency without changing the content

## Length

Total deliverable file should be 1500-2200 words.
