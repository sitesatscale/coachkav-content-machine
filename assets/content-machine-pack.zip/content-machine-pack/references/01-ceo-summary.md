# Deliverable 01: CEO Summary

## Purpose

A 1-page strategic overview the founder reads in 90 seconds before posting anything. It captures the spine of the pack: who she is talking to, what she stands for, what the pack drives toward, and why this set of assets in this order. The CEO Summary is the document she sends to her COO, her assistant, or a content VA so they can run the pack without needing a meeting.

## Output structure

The file follows this exact structure:

```markdown
# Content Machine Pack — {Founder First Name}

## Brand Context
{full brand context block from brand-context-template.md}

## CEO Summary

### The play in one paragraph
{4-6 sentence paragraph: who this pack is for, what shift it is making in the audience, what action it drives to, and why this matters now for the founder's business}

### The strategic spine
{3-5 bullets describing the through-line. Each bullet should be a single sentence that another team member could quote. Example bullet style:
- The contrarian wedge: she says X out loud while peers tiptoe around it
- The audience signal we are amplifying: customers calling this "Y" not "Z"
- The CTA gravity: every asset bends toward {primary CTA}}

### What the pack contains
{Numbered list of the nine deliverables with one line each on what role each plays in the system. Don't restate the filename, state the role:
1. CEO Summary: the strategic spine
2. Content Waterfall: how one piece of long-form becomes 12 pieces
3. Lead Magnet: the value trade that opens the relationship
4. Welcome Sequence: turns the email into a conversation
5. 30 LinkedIn Posts: builds authority on the primary platform
6. 30 X/Twitter Posts: tests one-liners that earn distribution
7. 5 IG Carousels: visual versions of the strongest posts
8. 5 LI Infographics: shareable proof-density artifacts
9. 30-Day Calendar: the schedule that actually runs}

### Voice rules in 5 lines
{5 short lines covering: how she sounds, what to avoid, her signature move, what tone is too far, and a one-line gut check the writer can apply to any draft}

### The CTA architecture
{2-3 sentences explaining the action ladder: which assets drive to which destination, where the lead magnet sits in the flow, and what counts as a win for this pack}

### The next 30 days
{3-5 bullets on tactical priorities. What to post first, what to test, what to measure, what to refine in week 3, and when to come back for the next pack}

### Risks and watch-outs
{2-3 short lines on places this pack could go wrong: voice drift, posting cadence, audience fatigue, off-limits topics that might tempt the writer}
```

## Tone

The CEO Summary is the most operational document in the pack. Write it like a Chief of Staff briefing the founder. Tight sentences, zero fluff, no marketing language. It is read once and referenced often.

## Length

Total CEO Summary content (everything below the brand context block) should be 400-700 words. Anything longer and the founder will not re-read it.

## What to avoid

- Don't restate the brand context block in prose. It is already at the top of the file.
- Don't write a generic strategy document. This is specific to her, her audience, her offer, and the nine deliverables that follow.
- Don't include section numbers or document references. Write it as if it were the only document she has.
- Don't end with a vague call to action like "let's get started." End with the risks section. The pack speaks for itself.
