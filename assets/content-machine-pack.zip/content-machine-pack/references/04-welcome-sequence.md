# Deliverable 04: 9-Email Welcome Sequence

## Purpose

The 9-email welcome sequence is the conversation that turns a lead magnet download into a buyer (or a permanently engaged reader). Each email has a single job. The sequence pushes the reader through awareness → trust → conviction → action, anchored in the founder's voice and POV.

## Sequence architecture

The 9 emails follow this exact functional structure. The topics adapt to the founder, but the function of each email is fixed.

| # | Function | Sent | Open intent | Close intent |
|---|----------|------|-------------|--------------|
| 1 | Deliver the magnet, set expectations | Immediately | Reader downloaded something, wants it now | Read the magnet today |
| 2 | Founder origin story | +1 day | Reader knows the topic, doesn't know her yet | Believe she has earned the right to teach this |
| 3 | The biggest myth in the industry | +2 days | Reader has consumed competitor content full of this myth | Believe the contrarian POV |
| 4 | A specific client win or case study | +3 days | Reader wants proof this works for someone like them | See themselves in the win |
| 5 | Common mistake the reader is probably making | +4 days | Reader nodded along to emails 1-4, now ready for tactical | Try the fix this week |
| 6 | A behind-the-scenes or values email | +6 days | Reader trusts her on tactics, now wants to know who she is | Feel they know her |
| 7 | The hidden cost of waiting / inaction | +8 days | Reader is curious but not moving | Feel the cost of staying still |
| 8 | Soft pitch with story | +10 days | Reader is warm, story-led pitch lands without friction | Click to learn more about the offer |
| 9 | Direct CTA with deadline or scarcity | +12 days | Reader is at the moment of decision | Book the call / buy / apply |

Sending cadence is a default. Adjust based on the founder's preferred pace and audience expectations.

## Output structure

```markdown
# 9-Email Welcome Sequence — {Founder First Name}

## Brand Context
{full brand context block}

## 9-Email Welcome Sequence

### Sequence overview
{One paragraph explaining the arc, the cadence, and where the sequence sends people (primary CTA, primary offer, sales call).}

### The 9 emails

For each email, produce this structure:

#### Email 01: {Functional name, e.g., "Magnet delivery + expectation setting"}

**Send:** Immediately on signup
**Function:** {one sentence}
**Subject line options (3):**
1. {option 1, 6-9 words}
2. {option 2, different angle}
3. {option 3, curiosity-led}

**Preview text:** {≤90 characters}

**Body:**

{Full email body in the founder's voice. 150-350 words depending on email function. Use line breaks every 1-2 sentences for mobile readability. No em dashes. Use second-person address.}

**CTA:** {explicit action with anchor text}
**Internal note:** {1 line for the writer or VA: what to watch for in replies, what to test, or what to swap if a different segment receives this}

---

[Repeat for emails 02 through 09]
```

## Per-email content rules

**Email 1:**
- Lead with delivery: the magnet link is the first thing they see, not buried.
- Set the cadence ("you'll hear from me every couple of days for the next two weeks").
- Ask one low-friction question or invite a reply. The reply rate on email 1 predicts the conversion rate on email 9.

**Email 2:**
- Tell the origin moment from the brand context block. Use it verbatim if possible.
- One specific scene. Concrete details. Sensory if she's that kind of writer.
- Close with the through-line: what this experience taught her about the topic the magnet addresses.

**Email 3:**
- State the contrarian POV from the brand context block directly in the body.
- Name the myth she is debunking.
- Use one specific example or piece of evidence.

**Email 4:**
- Use a real client win if the user provided one. If not, mark `[INSERT: specific client win with name, before-state, after-state, timeframe]` and flag in the internal note.
- The win should feel attainable to the reader, not aspirational-impossible.

**Email 5:**
- Pull the mistake from "common mistakes" in the lead magnet's outline.
- Give the corrective move concretely. The reader should be able to act on this email within 24 hours.

**Email 6:**
- Behind-the-scenes, values, or a "day in the life" angle. The point is human texture, not tactics.
- This email should be the founder's voice at its most natural. If she swears or uses humor, this is where it shows.

**Email 7:**
- Reframe inaction as a choice with a cost. Not fear-mongering. Honest accounting.
- Tie the cost back to the audience's desired outcomes from the brand context.

**Email 8:**
- Open with a story (client, peer, or her own). Pivot to the offer at the midpoint, not the opening.
- Include the offer name, format, and one-line promise. Not the full sales page.
- Soft CTA: "Reply if you want to hear more" or "Here's the page if you're curious."

**Email 9:**
- Direct CTA with a real reason to act now (next cohort, application deadline, price change, capacity).
- If no real urgency exists, do not manufacture one. Use a "this is the last email of the welcome series" angle instead and invite them to opt into a different newsletter.

## Voice rules

- Every email opens with a line that could be the first line of a text message to a friend.
- No "Hi {First Name}." Open with the line. The reader knows their own name.
- No "PS: stay tuned for more" filler. Every PS earns its place or doesn't exist.
- Em dashes are banned. Use commas, periods, or restructure.
- Maximum 350 words per email. Most should be 180-250.

## Tailoring quality bar

- At least 3 of the 9 emails reference a specific audience pain in the audience's own language
- At least 1 email uses the founder's signature verbal habit if one was given
- The contrarian POV appears (paraphrased or direct) in emails 3 and 7
- The primary CTA appears explicitly in emails 1, 8, and 9 (not in every email)
- Subject lines do not all sound the same. Mix curiosity, benefit, story, and direct.

## Length

Total deliverable file should be 2500-3500 words including all 9 email bodies.
