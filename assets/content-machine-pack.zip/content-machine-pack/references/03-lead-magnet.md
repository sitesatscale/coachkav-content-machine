# Deliverable 03: Lead Magnet

## Purpose

The lead magnet is the value trade that opens the email relationship and starts the journey to the primary offer. It is the gravitational center of the pack: every social post, every email, every cornerstone piece can drive to it. A lead magnet that does not ladder cleanly into the primary offer wastes the pack.

## Output structure

```markdown
# Lead Magnet — {Founder First Name}

## Brand Context
{full brand context block}

## Lead Magnet

### Concept
**Working title:** {3-5 word title that promises a specific outcome}
**Format:** {PDF guide, checklist, swipe file, mini-course, audio training, scorecard, calculator, template, etc.}
**Length / consumption time:** {pages and minutes to consume}
**The promise in one sentence:** {what the reader gets, who it is for, and what shift it makes}

### Why this magnet, for this audience, right now
{One paragraph of strategic rationale. Why this specific topic, why this specific format, and how it ladders into the primary offer. Reference the audience pains and the offer ladder from the brand context.}

### The ladder
{4-5 line walk-through of how the lead magnet leads to the primary offer:
- Magnet promise: solves problem X (small, specific)
- Reading reveals: the bigger problem Y the reader didn't know they had
- That bigger problem is what {primary offer} actually solves
- Next step is naturally: {primary CTA}}

### Title options
3 strong title options, ranked. Each title includes:
- The hook (specific outcome)
- The qualifier (who it is for)
- The proof (number, timeframe, or mechanism)

Example title patterns:
- "The {Specific Number}-Step {Outcome} Playbook for {Specific Audience}"
- "{Outcome} in {Timeframe}: A {Number}-Page {Audience} Guide"
- "The {Audience}'s {Counter-Intuitive Adjective} Guide to {Outcome}"

### Outline (page-by-page)

```
Page 1: Cover
{title, founder credential line, one-line promise}

Page 2: Why this exists
{2-3 paragraphs: the pain the magnet addresses, the cost of ignoring it, who this is for, who this is not for}

Page 3: What you'll get from these pages
{3-5 bullets of outcomes, written as second-person promises: "By the end you will know X, will be able to Y, and will have Z"}

Page 4: The frame
{1-page conceptual frame, model, or core insight. This is the founder's POV in concentrated form.}

Pages 5-N: The body
{Sub-sections by step, principle, or category. Each section: short intro, concrete example, one-line takeaway, and either a checklist, a script, a template, or a tactical instruction.}

Page N+1: Common mistakes
{4-5 bullets of mistakes the reader is probably already making, with the corrective move}

Page N+2: What to do next
{Soft CTA to the primary offer. Not a hard sell. A natural next step the reader would want after reading.}

Page N+3: About the founder
{4-6 sentence bio that earns authority. Specific numbers, specific clients, specific results. No marketing voice.}
```

Adapt the page count to the format. A checklist might be 4 pages. A mini-guide is 8-15. A swipe file is mostly assets with light scaffolding.

### Voice and design notes
{4-6 lines covering:
- Tone match to the founder's voice cues
- Visual style direction (clean and minimal, photo-heavy, infographic-heavy, etc.)
- Whether the magnet should feel like a high-end consulting deliverable or a fast tactical asset
- Branding density (heavy logo presence vs. content-forward)}

### Distribution copy

**Landing page hero (≤25 words):**
{Headline that promises the outcome}

**Sub-headline (≤30 words):**
{Sub-hook that names the audience and the specific transformation}

**Bullets (5):**
- {Outcome bullet 1: specific, time-bound, concrete}
- {Outcome bullet 2}
- {Outcome bullet 3}
- {Outcome bullet 4}
- {Outcome bullet 5}

**Form CTA button:** {3-5 word action verb starting with the verb}

**Email confirmation subject:** {6-9 words}

**Email confirmation body (≤80 words):**
{Quick: thank them, set expectation for the welcome sequence, deliver the magnet link, sign off in founder voice}
```

## Tailoring rules

- The magnet topic must address one of the audience pains from the brand context block **directly**. If you cannot map it to a specific bullet, it is the wrong topic.
- The ladder must connect to the **primary offer**, not to a vague "work with us." If the primary offer is a $25K consulting engagement, the magnet should reveal the kind of problem only consulting solves. If the primary offer is a $97 product, the magnet should leave the reader wanting the product, not a call.
- The magnet should be **readable in one sitting**. If the format is a 60-page ebook, push back — most magnets that long don't get finished.
- The "Why this magnet, for this audience, right now" section should reference the founder's contrarian POV. The magnet is her POV in deliverable form.

## Tone

The lead magnet copy itself (titles, hero, bullets) follows direct-response best practices. The outline and rationale read like a strategic brief.

## Length

Lead Magnet deliverable file should be 700-1100 words.
