# Deliverable 02: Content Waterfall

## Purpose

The Content Waterfall is the system that turns one piece of cornerstone content into 10-15 derivative pieces across platforms. It is not a list of posts. It is the repurposing logic that lets the founder publish at volume without writing at volume. Every other deliverable in the pack flows through this waterfall.

## Output structure

```markdown
# Content Waterfall — {Founder First Name}

## Brand Context
{full brand context block}

## Content Waterfall

### The cornerstone
{One paragraph defining the single weekly cornerstone piece. For most founders this is a long-form post, a newsletter, a podcast episode, or a recorded short talk. Specify format, length, and where it lives. Example: "One 800-word LinkedIn long-form post published every Tuesday at 7am ET. Topic pulled from the 5 content pillars on a rotating basis."}

### The waterfall map

A table showing how one cornerstone becomes 10-15 derivative pieces.

| # | Derivative asset | Source | Platform | Format | Estimated effort |
|---|------------------|--------|----------|--------|------------------|
| 1 | Cornerstone long-form | Original | LinkedIn | 800-word post | 90 min |
| 2 | Newsletter version | #1 expanded | Email | 1200 words | 30 min |
| 3 | Twitter thread | #1 condensed | X | 8-12 tweets | 20 min |
| 4 | 3 stand-alone X posts | #1 quotes | X | Single tweets | 10 min |
| 5 | Instagram carousel | #1 visual | IG | 8-10 slides | 60 min |
| 6 | LinkedIn carousel | #1 visual | LinkedIn | PDF carousel | 60 min |
| 7 | Short-form video script | #1 hook | IG Reels / TikTok / Shorts | 60-90 sec | 30 min |
| 8 | Quote graphic | Strongest line | IG / LinkedIn | Single image | 10 min |
| 9 | Comment-bait short post | Counter-take | LinkedIn | 100 words | 15 min |
| 10 | DM follow-up template | Audience reply | DM / Email | 4-6 lines | 10 min |
| 11 | Lead magnet excerpt | #1 deepest point | Newsletter / Sales page | 200 words | 15 min |
| 12 | Sales call talking point | Strongest objection-handling line | Internal | 1 paragraph | 5 min |

Use this template and adapt the platforms to match the founder's primary platform and audience. If she does not currently use a platform, do not add it just to fill the table.

### The weekly rhythm
{5-7 bullets covering: which day the cornerstone publishes, when each derivative drops, who produces what, and how the cycle restarts. Specific times and days, not "post regularly."}

### What goes in the cornerstone

The cornerstone has to do three things or it cannot be repurposed:
1. State a clear point of view (so a quote graphic exists)
2. Tell a specific story or use a specific example (so a thread exists)
3. Include a concrete takeaway, framework, or count (so a carousel exists)

{Adapt this section to the founder's content pillars. Give 2-3 examples of cornerstone post topics drawn from her actual pillars.}

### What the waterfall is not

{3-4 bullets clarifying what this is not, to prevent misuse:
- Not a posting schedule (that lives in the 30-day calendar)
- Not a content list (the 30 LI posts and 30 X posts are the list)
- Not a permission to repost identical copy across platforms — each derivative is reformatted, not duplicated
- Not a substitute for original thought — cornerstones still require fresh thinking each week}
```

## Tailoring rules

- The waterfall table should reflect the **founder's actual platforms**, not a generic stack. If she does not have a TikTok or does not want one, remove that row.
- The cornerstone format should match her **current strongest channel**, not the platform she wants to build. The waterfall amplifies existing strength; growth comes from the calendar.
- Effort estimates should be realistic. A founder who already writes well will produce a cornerstone in 90 minutes. A founder learning to write may need 3 hours. Adjust based on intake signals.
- If the founder has a team (VA, junior writer, designer), add a "Owner" column noting who handles each derivative. If solo, skip that column.

## Tone

The Content Waterfall is an operations document. Write it like a systems doc, not a sales pitch. Use tables, bullets, and short declarative sentences.

## Length

Total Content Waterfall content should be 500-900 words plus the table.
