# Deliverable 09: 30-Day Content Calendar

## Purpose

The calendar is the schedule that actually runs the pack. It assigns every piece of content generated above (the 30 LI posts, 30 X posts, 5 carousels, 5 infographics, lead magnet promotion, and welcome sequence triggers) to specific days. It is the last deliverable because it can only be built once everything else exists.

## Calendar architecture

The calendar maps a posting schedule across 30 days (4 weeks plus 2 days). Default cadence:

| Day type | LinkedIn | X | Instagram | Other |
|----------|----------|---|-----------|-------|
| Mon | 1 post | 2-3 posts | — | Newsletter (if weekly) |
| Tue | 1 post + 1 carousel/infographic | 2-3 posts | 1 carousel (if matching) | — |
| Wed | 1 post | 2-3 posts | — | — |
| Thu | 1 post + 1 carousel/infographic | 2-3 posts | 1 carousel (if matching) | — |
| Fri | 1 post (lighter/personal) | 1-2 posts | — | — |
| Sat | — | 1-2 posts | 1 carousel (optional) | — |
| Sun | — | 1 post | — | — |

Adapt to the founder's primary platform. If she is X-first, weight the X cadence higher and reduce LinkedIn. If she does not post on weekends, leave Sat-Sun blank and front-load the week.

## Output structure

```markdown
# 30-Day Content Calendar — {Founder First Name}

## Brand Context
{full brand context block}

## 30-Day Content Calendar

### Cadence overview
{4-5 lines summarizing posts per platform per week, the cornerstone day, and the lead magnet promotion rhythm}

### Weekly themes
- **Week 1: Foundation.** Establish voice and POV. Heavier on contrarian and story posts.
- **Week 2: Depth.** Tactical content, frameworks, lead magnet introduction.
- **Week 3: Proof.** Client wins, case studies, audit content, infographic-heavy.
- **Week 4: Conversion.** Push to primary CTA, soft pitch posts, sequence reactivation.

### The calendar

Format as a week-by-week breakdown. For each day, list every scheduled item with the source (which deliverable file and which post number).

#### Week 1

**Monday, Day 1**
- LinkedIn (7am ET): LI Post 03 (Contrarian take)
- X (8am, 12pm, 5pm): X Post 01, X Post 02, X Post 03
- Newsletter (10am ET): Cornerstone of the week — built around LI Post 03

**Tuesday, Day 2**
- LinkedIn (7am ET): LI Post 11 (Long-form story)
- LinkedIn (11am ET): IG Carousel 01 cross-posted as a LinkedIn carousel
- X (8am, 12pm, 5pm): X Post 04, X Post 05 (mini-thread starts)
- Instagram (6pm ET): IG Carousel 01

**Wednesday, Day 3**
[...]

[Continue through Day 30]

#### Lead magnet promotion schedule
- Day 1: Mentioned in cornerstone newsletter, no hard CTA
- Day 5: LinkedIn post with explicit CTA to download
- Day 9: X mini-thread closing with lead magnet
- Day 14: IG carousel with link-in-bio CTA
- Day 19: LinkedIn post leading with the lead magnet's most useful page
- Day 24: X long thread with lead magnet as CTA
- Day 28: LinkedIn post with lead magnet as primary CTA before week 4 pitch posts
- Day 30: Final push, all platforms

#### Welcome sequence triggers
Every new lead magnet subscriber enters the 9-email welcome sequence on signup day (Day 1 of their personal journey). Sequence content is from `04-welcome-sequence.md`.

### What to measure
{4-6 bullets:
- Posts published vs scheduled (consistency rate)
- Lead magnet conversion rate from each platform
- Email open rate on welcome sequence emails 1, 4, and 9
- Reply rate on email 1 (predicts sequence performance)
- Top 3 highest-engagement posts (for repurposing into the next pack)
- DM and comment volume on contrarian posts}

### Rebalancing rules
{4 lines: when to pause and reassess, when to extend a winning post into a series, when to retire a format that isn't landing, when to commission the next pack}
```

## Per-day assignment rules

- **Mondays open with a contrarian take.** Sets the tone for the week, earns reach.
- **Story posts go mid-week (Tues/Wed).** They earn the most time-on-post when the audience has attention.
- **Tactical and how-to posts go Thursday.** Audience is in execution mode by end of week.
- **Fridays are personal/values/behind-the-scenes.** Lighter content, humanizing.
- **Client wins go in Week 3.** By then the audience trusts the voice and is ready for proof.
- **Soft pitch posts go in Week 4 (Days 22-30).** Welcome sequence email 8 logic, but on social.
- **Carousels and infographics anchor Tuesdays and Thursdays.** Visual variety in the feed mid-week.

## Mapping rules

When assigning specific posts from the 30 LI and 30 X packs to specific days:
1. Spread contrarian takes across the 4 weeks. Never two in the same week.
2. Front-load long-form story posts in Weeks 1-2 (build trust before pitching).
3. Hold client wins for Week 3.
4. Reserve the 3 strongest LinkedIn posts (by gut feel from the pack) for Days 1, 14, and 28.
5. Reserve the long X threads for Days 3, 17, and 25 (mid-week, when threads earn dwell time).
6. Match Instagram carousels and LinkedIn infographics to the LinkedIn cornerstone topic of the same week.

## Tailoring rules

- The calendar must match the founder's **actual platform mix**, not a textbook stack. If she doesn't use Instagram, remove that row entirely.
- Posting times should reflect her **audience's timezone**, not hers. Pull from the brand context geography field.
- If the founder has **stated cadence preferences** in the intake ("I can only post 3 times a week on LinkedIn"), honor them. Drop the lowest-priority items, not the highest.
- The calendar should never schedule more than the founder can realistically execute. Better to publish 60% of a tight calendar than 30% of an aspirational one.

## Length

Total deliverable file should be 2000-3000 words including the day-by-day breakdown.
