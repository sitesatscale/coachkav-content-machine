# Deliverable 07: 5 Instagram Carousel Concepts

## Purpose

5 Instagram carousel concepts, each with a full slide-by-slide outline ready for a designer (or the founder's Canva workflow). Carousels are the highest-saving format on Instagram and the format most likely to send a viewer to the bio link, which makes them direct contributors to lead magnet downloads.

## Carousel architecture

Every carousel follows this structure:

1. **Cover slide:** The hook. The reason someone stops scrolling.
2. **Slide 2 — Stakes:** Why this matters now. The cost of not knowing.
3. **Slides 3-7 — The meat:** One idea per slide. Numbered, listed, or stepped.
4. **Slide 8 — The shift:** The reframe, takeaway, or "what this means for you."
5. **Slide 9 (optional) — Proof:** A client win, a stat, or a one-line endorsement.
6. **Final slide — CTA:** Save, share, follow, or link in bio.

Total slides: 8-10. Don't go shorter (too thin) or longer (drop-off kills the algorithm).

## The 5 concepts

Generate 5 carousel concepts spanning these strategic functions. One carousel per function:

| # | Concept type | Strategic function |
|---|--------------|-------------------|
| 1 | The Contrarian Carousel | Plant the flag on the founder's strongest opinion |
| 2 | The Mistakes Carousel | "{N} mistakes {audience} keep making" — high-save format |
| 3 | The Framework Carousel | A model, system, or numbered method the founder owns |
| 4 | The Story Carousel | A specific client transformation or origin story, told visually |
| 5 | The Audit Carousel | A teardown of a real example (anonymous if needed) showing before/after |

## Output structure

```markdown
# 5 Instagram Carousel Concepts — {Founder First Name}

## Brand Context
{full brand context block}

## 5 Instagram Carousel Concepts

### Visual style direction
{4-6 lines covering: brand colors, typography direction, whether text-heavy or image-led, photo vs illustration preference, whether the founder appears on cover slides, density of text per slide}

### The 5 concepts

#### Carousel 01: {Concept type} — "{Working title}"

**Strategic function:** {one line on what this carousel is doing in the broader pack}
**Pillar:** {which content pillar}
**Estimated production time:** {30-90 min depending on complexity}

**Slide-by-slide outline:**

**Slide 1 (Cover):**
Headline: "{exact text, ≤8 words}"
Sub-text (optional): "{exact text, ≤12 words}"
Visual note: {what the slide should look like — photo of founder, bold typography on color block, illustration, etc.}

**Slide 2 (Stakes):**
Headline: "{≤10 words}"
Body: "{1-2 sentences, ≤30 words}"
Visual note: {brief}

**Slides 3-7 (The meat):**
For each slide:
- Slide headline: "{≤8 words}"
- Slide body: "{≤30 words, often a single sentence}"
- Visual note: {brief}

**Slide 8 (Shift):**
Headline: "{the reframe in ≤10 words}"
Body: "{1-2 sentences}"
Visual note: {brief}

**Slide 9 (Proof, optional):**
{Content}

**Slide 10 (CTA):**
Headline: "{≤8 words: "Save this," "Share this with X," etc.}"
Sub-CTA: "{link-in-bio reference to the lead magnet}"

**Caption:**
{Full caption ready to publish. 100-220 words. Opens with the strongest line from the carousel. Closes with a CTA that mirrors the final slide.}

**Hashtag set:**
{8-12 hashtags, mix of niche (10K-100K) and medium (100K-1M) tags relevant to the founder's space. No mega-tags above 1M.}

---

[Repeat for carousels 02 through 05]
```

## Per-concept content rules

**Carousel 1 (Contrarian):**
- The hook is the contrarian POV from the brand context block, sharpened
- Slides 3-7 walk through the evidence: industry pattern, audience symptom, the cost, the counter-move, the result
- This is the carousel that polarizes — that is the point

**Carousel 2 (Mistakes):**
- 5 specific mistakes, one per slide
- Each mistake names the symptom and the corrective move in the same slide
- The mistakes come from real patterns the founder has seen, not generic "mistakes" lists

**Carousel 3 (Framework):**
- Open with the name of the framework. If she doesn't have one yet, propose 2-3 name options.
- Slides 3-7 walk through each step or component
- Slide 8 reframes the framework as the alternative to the audience's current chaos

**Carousel 4 (Story):**
- A specific client (anonymized if needed) or the founder's origin moment
- Treat each slide like a scene. Setup, tension, turn, resolution, lesson.
- Avoid generic "she was struggling, now she's thriving" arcs. Specifics on what she was doing, what she stopped, what she started.

**Carousel 5 (Audit):**
- A real example (anonymized) showing before-state in detail
- Slides 3-5 show what's wrong, slides 6-7 show what to do instead
- This format converts because the reader sees themselves in the audit

## Tone

Instagram captions can be slightly warmer and more emotional than LinkedIn or X. The visual carries the cleverness, so the caption can be more direct and human.

## Tailoring quality bar

- At least 3 of the 5 carousels are built around content the founder has not posted before in long-form (so the carousel feels fresh)
- The contrarian carousel echoes the brand context POV verbatim or near-verbatim
- The captions reference specific audience pains in the audience's own words
- Visual notes are concrete enough that a designer who has never spoken to the founder could execute them

## Length

Total deliverable file should be 2200-3200 words.
