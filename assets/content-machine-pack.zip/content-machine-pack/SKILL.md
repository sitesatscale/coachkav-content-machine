---
name: content-machine-pack
description: |
  Generate a complete Content Machine Pack for a specific founder or brand, modeled on the Founder OS deliverable structure. Produces nine separate .md files in one run: CEO Summary, Content Waterfall, Lead Magnet, 9-Email Welcome Sequence, 30 LinkedIn Posts, 30 X/Twitter Posts, 5 Instagram Carousel Concepts, 5 LinkedIn Infographic Concepts, and 30-Day Content Calendar. Auto-detects whether the user has already pasted a Brand DNA doc or intake and pulls context from it, or whether to walk the user through a structured intake first. Trigger whenever the user asks for a Content Machine, Content Machine Pack, full content build, content asset pack, founder content launch pack, or wants a full set of content deliverables for a client, founder, or brand. Also trigger when the user pastes a Brand DNA, brand strategy doc, or intake form and says "build the content pack" or "run the content machine." Trigger even when the user only mentions a client name and "content machine" together.
---

# Content Machine Pack

## What this skill does

Generates a full Content Machine Pack for one specific founder or brand. The pack contains nine deliverables, each as a separate `.md` file in `/mnt/user-data/outputs/`. Every deliverable is grounded in the same brand context block so the voice, niche, audience language, and offer all stay consistent across assets.

The output is built to feel custom to the client. If the same pack would read identically with another founder's name swapped in, it was not tailored deeply enough.

## When to use

Trigger this skill when the user:
- Asks for a Content Machine Pack, Content Machine, full content build, or founder content launch pack
- Pastes a Brand DNA doc, brand strategy document, intake form, or onboarding questionnaire and asks for content built from it
- Names a client and asks for "the full content pack," "the nine deliverables," or similar
- References any subset of the deliverables (e.g., "build the welcome sequence and the 30 LinkedIn posts") as part of a broader content build

If the user only wants one deliverable in isolation (just the 9-email sequence, just the LinkedIn posts), do not run the full pack. Generate the single asset using the relevant reference file, or hand off to the `copy-engine` skill if it is a single ad or page.

## Workflow

### Step 1: Auto-detect input mode

Scan the conversation and any uploaded files for a Brand DNA document, brand strategy doc, intake form, onboarding questionnaire, or substantial brand context (founder name, business, niche, audience, offer, voice).

**Mode A: Context is present.** If the user has already provided enough context to populate the brand context block (founder name, business, niche, ICP, primary offer, voice cues), proceed to Step 2.

**Mode B: Context is missing or thin.** If there is no Brand DNA doc and no substantial intake, load `references/intake-template.md` and walk the user through the intake before proceeding. Ask all the questions in one message, numbered, so the user can answer in one pass.

**Mode C: Partial context.** If the user has provided some context but key fields are missing (e.g., they named the founder and business but did not give audience or offer details), ask only for the missing fields. Do not re-ask what they already gave you.

In Modes B and C, wait for the user's answers before generating anything.

### Step 2: Build the brand context block

Once you have the inputs, populate the brand context block using `references/brand-context-template.md`. This block becomes the shared header that grounds every deliverable. Fill every field. If a field is genuinely unknowable from the inputs, mark it `[TO CONFIRM]` rather than inventing.

The brand context block contains:
- Founder name and credentials line
- Business name, category, and niche
- Stats line (revenue, clients served, years in business, awards) where available
- ICP definition in plain language
- Primary offer and price band
- Three to five audience pains in the audience's own words
- Three to five desired outcomes in the audience's own words
- Voice cues (three adjectives, two things the voice avoids)
- Founder POV or contrarian belief (one or two sentences)
- Five to ten content pillars or topic territories

Hold this block in context. Every deliverable references it.

### Step 3: Confirm the build before generating

Before generating files, show the user the populated brand context block and ask:

```
Here is the brand context I will use for every deliverable. Confirm or correct anything below, then I will generate all nine files.

[brand context block]

Anything to change before I run the build?
```

Wait for confirmation. If the user corrects anything, update the block and re-show it briefly before proceeding.

### Step 4: Generate all nine deliverables

Read each reference file and produce the corresponding `.md` file in `/mnt/user-data/outputs/`. Each file starts with the brand context block as a collapsed header, then the deliverable content.

Generate in this exact order. Each one builds on the prior:

| # | Deliverable | Output filename | Reference file |
|---|-------------|-----------------|----------------|
| 1 | CEO Summary | `01-ceo-summary.md` | `references/01-ceo-summary.md` |
| 2 | Content Waterfall | `02-content-waterfall.md` | `references/02-content-waterfall.md` |
| 3 | Lead Magnet | `03-lead-magnet.md` | `references/03-lead-magnet.md` |
| 4 | 9-Email Welcome Sequence | `04-welcome-sequence.md` | `references/04-welcome-sequence.md` |
| 5 | 30 LinkedIn Posts | `05-linkedin-posts.md` | `references/05-linkedin-posts.md` |
| 6 | 30 X/Twitter Posts | `06-twitter-posts.md` | `references/06-twitter-posts.md` |
| 7 | 5 Instagram Carousel Concepts | `07-instagram-carousels.md` | `references/07-instagram-carousels.md` |
| 8 | 5 LinkedIn Infographic Concepts | `08-linkedin-infographics.md` | `references/08-linkedin-infographics.md` |
| 9 | 30-Day Content Calendar | `09-content-calendar.md` | `references/09-content-calendar.md` |

**Why this order matters:**
- The CEO Summary defines positioning that the rest of the pack references
- The Content Waterfall defines the repurposing logic that the calendar enforces
- The Lead Magnet defines the CTA that the welcome sequence delivers and the social posts drive to
- The welcome sequence sets the voice and depth that social copy then echoes in shorter form
- The calendar sequences everything generated above into a 30-day schedule

For each deliverable: read the reference file, generate the file using `create_file`, then move to the next. Do not skip ahead and do not generate in parallel — later deliverables need to reference earlier ones (e.g., the calendar must reference specific post numbers from deliverables 5 and 6).

### Step 5: Present the files

After all nine files are created, call `present_files` with all nine paths in numerical order. Then deliver a short summary (no more than 6 lines of prose) covering:
- Confirmation that the pack is complete
- One sentence on the strategic spine of the pack (the through-line in the founder's positioning)
- A note that the brand context block at the top of each file can be edited and used as the source of truth for future content

Do not narrate the build process. Do not list every file again — `present_files` already shows them.

### Step 6: Offer next moves

End with a short tail offer:

```
Want me to extend the calendar to 60 or 90 days, generate the next 30 LinkedIn posts, or produce the ad-creative pack (Meta primary text, headlines, hooks) from this same brand context?
```

## Output formatting standards

These apply to every deliverable file:

1. **Brand context block at the top.** Every file starts with the same context block under a `## Brand Context` header. This makes each file a standalone artifact the client can edit without losing grounding.
2. **No em dashes anywhere.** Use commas, periods, "and," or restructure the sentence.
3. **No horizontal rules.** No `---` line breakers inside the body. Use header hierarchy and spacing.
4. **Plain professional tone in scaffolding.** Section headers, intros, and instructions are clean prose. The content itself can match the founder's voice (which may be punchier or more casual).
5. **No emoji unless the founder's voice explicitly uses them.** If the brand context block lists emoji as a voice cue, allow them in social copy only.
6. **Numbered posts and emails.** Use `1.`, `2.`, `3.` not bullets. Posts get headers like `### LinkedIn Post 01`.
7. **Specifics over abstractions.** Every post should be runnable as-is. If a post requires the founder to plug in a number or example, mark that inline with `[INSERT: specific number or example]`. Aim for fewer than 10% of posts needing inline inserts.
8. **No operator branding anywhere.** No mention of Coach Kav, Justin Kavanaugh, Sites at Scale, or any agency, platform, or creator identity in any output file. No "Powered by," "Created by," "Developed by," or equivalent credits. No operator-specific signature closes. See White-Label Output Rule below.

## Tailoring quality bar

A deliverable is well-tailored when:
- The founder's name, business, and niche appear naturally in the body, not just the header
- At least three audience pain points from the brand context appear verbatim somewhere in the pack
- The founder's contrarian POV or strongest opinion drives at least five of the social posts
- The lead magnet topic ladders directly into the primary offer
- The welcome sequence references the lead magnet's specific value, not generic onboarding

If a deliverable could be search-replaced to fit another founder, it failed the bar. Rewrite it.

## White-Label Output Rule

This skill is deployed as a lead magnet. Prospects opt in and receive a custom Content Machine Pack built for their brand. Every file they download must read as though it was created exclusively for them. There is no agency credit, no operator signature, and no trace of any brand other than the founder whose Brand DNA is active.

**Hard prohibitions across all nine output files:**

- No mention of Coach Kav or Justin Kavanaugh
- No reference to Sites at Scale or any agency, platform, or operator
- No "Powered by," "Created by," "Developed by," or equivalent attribution lines
- No operator-specific signature closes (e.g., "That's how you WIN," "WIN the Right Way") unless those exact phrases appear in the client founder's own brand context block
- No cross-promotion of any service, product, or brand not supplied in the client's intake

**What belongs in the outputs instead:**

- All voice, frameworks, and POV attributed to the founder whose brand context is active
- Frameworks and systems described generically (e.g., "a 9-email welcome sequence," not "the [Brand X] welcome framework")
- The CEO Summary closing section names the founder's next move only, no external credits
- Footers, if included by the generating environment, must contain only the founder's business name

If any of these prohibitions would be violated by a proposed output, revise before writing the file. Do not flag it to the user — simply write it clean.

## Edge cases

**The user has the Brand DNA doc but it is light on audience language.** Generate the pack but flag at the top of the CEO Summary: "The audience pain bullets below are extrapolated from positioning. Replace with verbatim pulls from a Voice of Customer pass when available." If the `tub-customer-research-analyst` skill is available, recommend running it before the next pack iteration.

**The user wants the pack in a non-English language.** Generate the brand context block in English (so it is reusable across the agency), but generate every content deliverable in the target language. Keep voice cues intact during translation. Watch for em dashes sneaking back in.

**The user wants only a subset of the nine deliverables.** Honor that. Generate only what they asked for, in the canonical order, and skip the rest. Still produce the brand context block as the first file (`00-brand-context.md`) so the partial pack is portable.

**The founder has multiple offers.** Default the pack to the offer the user names as primary. If unclear, ask which offer the pack should ladder toward. Do not split a single pack across multiple offers — that dilutes every deliverable.

**The intake is very thin (a few sentences).** Generate the pack but mark `[TO CONFIRM]` aggressively in the brand context block. Flag at the top of the summary file that the pack is a v0 draft and should be refined after a 30-minute brand call.

**Conflicts with the user's claims.** If the user asserts something in the intake that contradicts standard direct-response or content best practices (e.g., "do not include a CTA in any email"), follow their instruction in the deliverables but flag it once in the CEO Summary so the choice is visible.

## Reference files

Detailed instructions for each deliverable live in `references/`. Read the relevant file immediately before generating that deliverable — do not work from memory.

- `references/intake-template.md` — Question set for Mode B (no Brand DNA doc)
- `references/brand-context-template.md` — The shared context block schema
- `references/01-ceo-summary.md` — CEO Summary structure and tone
- `references/02-content-waterfall.md` — Cross-platform repurposing matrix
- `references/03-lead-magnet.md` — Lead magnet build, ladder, and outline
- `references/04-welcome-sequence.md` — 9-email sequence structure and per-email briefs
- `references/05-linkedin-posts.md` — 30 LinkedIn posts with format variety rules
- `references/06-twitter-posts.md` — 30 X/Twitter posts and thread variants
- `references/07-instagram-carousels.md` — 5 carousel concepts with slide-by-slide outlines
- `references/08-linkedin-infographics.md` — 5 infographic concepts with visual logic
- `references/09-content-calendar.md` — 30-day calendar that schedules everything above

Always read the reference file fresh, even if you have generated this deliverable before in another session. The references are the source of truth.
